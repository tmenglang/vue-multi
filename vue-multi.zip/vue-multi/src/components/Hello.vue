<template>
  <div>
  	tpl
  </div>
</template>

<script>

import Lib from 'assets/Lib.js'

module.exports = {
	components:{
		
	},
  data: function () {
    return {
      msg: 'Hello moto! what`s up,yaoyao'
    }
  },
  ready(){
  	
  },
  methods:{
  	
  },
  props:{
  	
  }
}
</script>


<style scoped>

</style>
