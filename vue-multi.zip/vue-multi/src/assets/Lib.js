
import 'assets/css.css';
import $ from 'jquery';
import C from 'assets/conf';
import M from 'assets/common';


var Rxports = {
	M,C
};

module.exports = Rxports

