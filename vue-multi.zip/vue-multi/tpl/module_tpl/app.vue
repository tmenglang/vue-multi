<template>

tpl

</template>

<script>

import Lib from 'assets/Lib.js'


export default {
  data() {
    return {

    }
  },
  components: {

  },
  ready(){
  	
  },
  methods: {

      
  }
}
</script>

<style scoped>


</style>





