<template>
<div>

<module-head title="组件 header"></module-head>

<div class="widget">
  <div class="widget-header">
    <div class="title">
      Cool Tabs
    </div>
  </div>
  <div class="widget-body">
    <ul class="nav nav-tabs no-margin myTabBeauty">
      <li class="active">
        <a href="#home" v-on:click="tabsTrans">
          Traffic sources
        </a>
      </li>
      <li class="">
        <a href="#profile" v-on:click="tabsTrans">
          Referrals
        </a>
      </li>
    </ul>
    <div class="tab-content" id="myTabContent">
      <div id="home" class="tab-pane fade active in">
        <p>
          Nesciunt tofu stumptown aliqua, retro synth master cleanse. Reprehenderit butcher retro keffiyeh dreamcatcher synth terry richardsoAustin.
        </p>
        <p class="no-margin">
          Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica.prehenderit butcher retro keffiyeh dreamcatcher synth. Cosby Reprehenderit butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure squid.Raw denim you probably haven't heard of them jean shorts Austin.
        </p>
      </div>
      <div id="profile" class="tab-pane fade">
        <p>
          Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master cleanse. Reprehenderit butcher retro keffiyeh dreamcatcher synth terry richardsoAustin. Nesciunt tofu stumptown aliqua, retro synth master cleanse.
        </p>
        <p>
          Mustache cliche tempor, .prehenderit butcher retro keffiyeh dreamcatcher synth. Cosby Reprehenderit butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure terry richardson ex squid.
        </p>
      </div>
    </div>
  </div>
</div>

</div>
<module-footer title="组件 footer"></module-footer>
</template>

<script>

import Lib from 'assets/Lib.js'

import moduleHead from 'components/module-head'
import moduleFooter from 'components/module-footer'
export default {
  methods: {
    tabsTrans: function (event) {
      var dom = $(event.target)
      var id = dom.attr('href').split('#')[1];
      $('.tab-pane').removeClass('active in');
      $('#' + id).addClass('active in');
      $('.myTabBeauty li').removeClass('active');
      dom.parent().addClass('active');
    }
  },
  components: {
	  moduleHead,
    moduleFooter
  },
  ready(){
  }
}
</script>

<style scoped>


</style>