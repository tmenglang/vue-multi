<template>
<div>

<module-head title="组件 header"></module-head>

<div class="widget">
  <div class="widget-header">
    <div class="title">
      Ordered List
    </div>
  </div>
  <div class="widget-body">
    <ol class="no-margin">
      <li v-for="el in list">
        <span>
        {{el.msg}}
        </span>
      </li>
    </ol>
  </div>
</div>

</div>
<module-footer title="组件 footer"></module-footer>
</template>

<script>

import Lib from 'assets/Lib.js'

import moduleHead from 'components/module-head'
import moduleFooter from 'components/module-footer'
export default {
  data() {
    return {
		  list:[
        {msg: 'Lorem ipsum dolor sit amet'},
        {msg: 'Lorem ipsum dolor sit amet'},
        {msg: 'Lorem ipsum dolor sit amet'},
        {msg: 'Lorem ipsum dolor sit amet'},
        {msg: 'Lorem ipsum dolor sit amet'},
        {msg: 'Lorem ipsum dolor sit amet'},
        {msg: 'Lorem ipsum dolor sit amet'},
        {msg: 'Lorem ipsum dolor sit amet'},
        {msg: 'Lorem ipsum dolor sit amet'}
      ]	
    }
  },
  components: {
	  moduleHead,
    moduleFooter
  },
  ready(){
  	
  	
  },
  methods: {

	
  
  }  
}
</script>

<style scoped>


</style>





