import Vue from 'vue'
import App from './app'





/* eslint-disable no-new */
new Vue({
  el: 'body',
  components: { App }
})
