<template>

<footer id="footer">

{{title}}

</footer>

</template>

<script>

import Lib from 'assets/Lib.js'

module.exports = {
  props:{
  	"title": {
  		type:String,
  		default:"Author by Xmg"
  	}
  }
}
</script>


<style scoped>

#footer{
    background:#262626;
    color:#fff;
    padding:10px 0;
    text-align:center;
}

</style>
